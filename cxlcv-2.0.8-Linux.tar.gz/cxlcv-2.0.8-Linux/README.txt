Quickstart Guide to CXL CV CLI

Note: Please run cxlcvcli under sudo/root.

For additional options to pass into/and usage for cxlcvcli:
./cxlcvcli --help

For commands to cxlcvcli you can run command:
help

To check if there is a CXL device trained:
devices --sut

To see the list of testcases:
tests

For the run usage menu:
run

To run all available testcases:
run --all

To run an entire spec:
run --spec [spec number]
run --spec 1.1
run --spec 2.0

To run an entire group:
run --group [group name]
run --group CFG

To run an individual test:
run -t [spec]/[group]/[id]
run -t 1.1/CFG/1

To generate an HTMl report of the results:
report
