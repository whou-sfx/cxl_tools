#!/bin/bash

LD_LIBRARY_PATH=/usr/local/lib:/usr/lib:/usr/local/lib64:/usr/lib64:./lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

exec ./bin/cxlcvcli --testcasefile ./share/cxlcv/testcases.json "$@"
