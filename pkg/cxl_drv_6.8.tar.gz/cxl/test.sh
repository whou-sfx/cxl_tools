sudo modprobe -r cxl_pci cxl_port cxl_acpi cxl_core

sudo insmod ./core/cxl_core.ko
sudo insmod ./cxl_pci.ko
