/*
 * Copyright (C) 2021 Avery Design Systems, Inc.
 *
 * This work is licensed under the terms of the GNU GPL, version 2 or later.
 * See the LICENSE file in the top-level directory.
 */

#ifndef DOE_API_H
#define DOE_API_H

#define DOE_MBOX_CMD 0
#endif /* DOE_API_H */
