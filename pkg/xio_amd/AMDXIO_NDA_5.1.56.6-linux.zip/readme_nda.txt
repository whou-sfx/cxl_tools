Release Notes For:	AMD Xpress IO Tool 
Version:          	5.1.56
Release Date:		10-July-2024

---General Description---
AMD Xpress IO Tool is console utility to control AMD CPUs in diagnostic environments. It allows users to provide scope eye for PCIe, XGMI, SATA & USB lanes and margining for xGMI, PCIe GEN4/GEN5 lanes, ASPM (Active State Power Management) module displays and controls the devices PCIe® power management functionality, device's L0s and L1 status and control, PCIe® Port Status module displays the status of registers for the PCIe ports, Performance Counters module monitors the available counters for supported devices to assist in debugging, including features that logs counter values and can store or load counter configurations, PCIe Link Control module is used to monitor status of PCIe® devices. You can monitor the root complex (RC) as well as the end point (EP) of supported device.

---Supported Families---
•	Family 19h Models 10h-1Fh
•	Family 19h Models A0h-AFh
•	Family 1Ah Models 00h-0Fh 
•	Family 1Ah Models 10h-1Fh

---Improvements and Fixes---

Version 5.1.56
•      PCIe margin fixes
•      Modified link retrain sequence to perform link equalization as optional feature

Version 5.1.55
•      UI Fixes
•      Retimer margin fixes

Version 5.1.53
•      Added support for dGPU and Client family
•      Added support to force DPM

Version 5.1.52
•      Added support for dGPU and Client family
•      UI Fixes 

Version 5.1.51
•      Fixed issues in SMN read on MI300C Die 0
•      Fixed the slowdown in 4Pt XGMI margin

Version 5.1.50
•      Added additional new columns in PCIe and xGMI margin report
•      Added preset sweep feature for xGMI and PCIe

Version 5.1.49
•      Enhanced error handing for xGMI 4pt

Version 5.1.48

Version 5.1.47
•      EyeScan plotter updated
•      PCIe port listing to show package name where applicable.

Version 5.1.46
•      MI300X0 XGMI link status bug fix

Version 5.1.45

Version 5.1.44

Version 5.1.43
•     Added ESM support for PCIe

Version 5.1.42
•     Added logger framework for AMDXIO
•     Added PCIe Coefficient dump feature

Version 5.1.41
•     Fixed margin training data mismatch issue
•     Fixed 4pt core dump issue

Version 5.1.40
•     4pt margin tool crash.

Version 5.1.39
•     Lane data offset updated for eyescan and xgmi margin.
•     Eye plot failing on folder with space.
•     Common help file for Linux and Windows.
•     Duplicate console output in xgmi margin.
•     Multiple BDF support for retimer margining.
•     4PT margin support for retimer

Version 5.1.38
•     Add feature to support apu/dgpu for xgmi margin.
•     Add range support in -i switch.  

Version 5.1.36
•      PCIe Multi Segment PCIe 4PT bug fix

Version 5.1.35
•      PCIe Multi Segment support

Version 5.1.33
•      Added Link Partner link width renegotiation support check in PCIe Link width change sequence
•      PCIe RP Margin Value showing as 0
•      Added feature to perform SBR after in 4PT PCIe margin.

Version 5.1.32
•      Wafl Link Status

Version 5.1.31
•       Multi socket eye issue fixed.
•       Phy Margin enhanced to run optimally.

Version 5.1.30
•       System detection topolocy changes.

Version 5.1.28
•       PCIe Margin is not Woking for x4 lane reversal card.

Version 5.1.27
•       Added feature to perform SBR after each PCIe margin run.

Version 5.1.26
•       Missing information for Phy data for Upstream ports.
•       xGMI E32 Run-to-Run Variation.

Version 5.1.25
•       Enhanced xGMI link status to handle varying width.
•       Enabled parallel non-destructive margining method.
•       Added USB3 Eye Diagram support.

Version 5.1.24
•       EyeScan issue when run on multiple lanes.
•       Remove Recovery count from AMDXIO AER feature.
•       Enabled logic to disable power states before xGMI Margin.
•       SBR, Retrain and Enable/Disable Stall when executed from GUI.

Version 5.1.23
•       Bug fix to correct socket and die id detection in certain configs.
•       Parallel PCIe lane margining for devices which support it.
•       PCIe Phase1 USP_TX preset func 2/3 missing
•       Parallel PCIe BDF targetting - upstream and downstream port differniation.

Version 5.1.22
•       Only run margin on external port by default for all switch

Version 5.1.22
•       Only run margin on external port by default for all switch
•       PCIE port status contLoopContRun default time need to be change to 5s 

Version 5.1.21
•       Dump BIOS version and Phy FW version with AMDXIO in margin report.
•       Added faeture to dump TxEq data for all the lanes in device.

Version 5.1.20
•       Parallel pcie bdf targeting
•	Add option for multiple PCIe margining runs in single command.

Version 5.1.19
•	Added ability to run multiple instances of AMDXIO using the "-multilaunch" switch.
•	Added support for "-all" switch for PCIe 4pt.

Version 5.1.18

Version 5.1.17
•	MI300XO - support for 8P XGMI Links

Version 5.1.16

Version 5.1.15
•	Added XGMI 4PT margin parallel lane feature.
•	Added output file for xGMI BER polling.
•	Modified -margin -all reports to dump in single folder with time stamped files.
•	Enabled PCIe 4PT margin with split DAC and PHASE range.

Version 5.1.12
•	Enabled "-dwelltime" switch support for PCIe and xGMI margin.

Version 5.1.11
•	Enabled AER monitor feature
•	Added lane mapping algorithm to handle all physical to logical lane mapping during reversal scenario
•	PCIe margin commands(RP,EP) not taking user dwelltime details
•	Enable receiver option for pcie margin all 

Version 5.1.10
•	Added Port Controller details in PCIe margin reports.
•	Added additional values,speed, tool version, dwell time in XGMI margin reports.	

Version 5.1.9


Version 5.1.8
•	XGMI margin cmd line able to define seperate devices.
•	Linux builds made dynamic.

Version 5.1.7
•	CXL Device enumeration and margin support added.

Version 5.1.6
•	PCIe Link Stress enhanced for Sequential Speed Change

Version 5.1.5
•	Enhanced PCIe perf counter to display BDF per counter.
•	Enabled USR link status.

Version 5.1.4
•	Fixed offset reporting issue.
•	Enabled PCIe perf counter and PCIe port status.
•	Enabled USR perf counter.

Version 5.0.23

Version 5.0.22
•	"-all" switch support added for xgmi margin
•	link parallel margin for xgmi added

Version 5.0.16
•	Added xgmi lane margining.
•	Added xgmi link status command.

Version 5.0.15

Version 5.0.13

Version 5.0.12
•	Added -lanes switch for pcie margining.

Version 5.0.11

Version 5.0.10

Version 5.0.9

Version 5.0.8
•	Updated help file.
•	Corrected BER calculation in eye scan.

Version 5.0.7
•	Fixed issue in port mapping code.

Version 5.0.6
•	Fixed a bug in eye scan.

Version 5.0.5
•	PCIe link control support
•	PCIe Performance monitor support

Version 5.0.4
•	XGMI and PCIe Margining support.
•	EyeScan support.

Version 5.0.0
•	EyeScan support.


---Usage Notes---
amdxio must be run in a command line environment.
amdxio_ui for launching UI.   


This software installs and operates under the following operating systems:
* SuSe 13.x
* RHEL 8.x
* CentOS 8.x
* Ubuntu 18.x
